<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div class="cabecalho">
      <img src="../src/assets/img/Logo.png" alt="">

    </div>
  </header>

  <RouterView />
 
    <footer>
  
    </footer>
    <div>
      <nav>
        <RouterLink to="/">Home</RouterLink>
        <RouterLink to="/cadastro">Cadastro</RouterLink>
        <RouterLink to="/login">Login</RouterLink>
      </nav>
    </div>
</template>

<style scoped>
header {
  height:130px;
  background-color: rgba(43, 121, 195, 1);
}
footer{
  background-color: rgba(43, 121, 195, 1);
  height: 130px;
  width: 100%;
  display: block;
  padding-top: 0%;
  margin-top: 0%;
  border: none;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}



</style>
