<template>
    <div>
        <img src="../assets/img/imgCadeirante.jpg" alt="">
    </div>
            <h2>
            Bem-vindo à empresa de transporte especial MOBILIDADE, onde a sua mobilidade é a nossa prioridade. Nossa missão é oferecer transporte seguro, acessível e confiável para cadeirantes e pessoas com mobilidade reduzida.
        </h2>
   
   

</template>
<style scoped>
    img{
        width: 1200px;
        height: 100%;
        align-items: center;
        justify-content: center; 
    }
   div{
    align-items: center;
    justify-content: center; 
    display: flex
   }
   h2{
    align-items: center;
   }
</style>
