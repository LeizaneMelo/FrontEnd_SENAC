<template>
<h1>Essa é a tela de cadastro</h1>
</template>